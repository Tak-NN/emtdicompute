"""Regression checks; all temporary files are kept under repository/test-env."""
import contextlib
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import pandas as pd
import torch
import trimesh

from emtdicompute.scene import sample_mesh
from emtdicompute import main
from emtdicompute.utils.datatypes import CameraPosDir, SampleMesh


class CacheTests(unittest.TestCase):
    def run_batch_with_cache(self, **options):
        records=self.work/'records'
        records.mkdir(exist_ok=True)
        (records/'trial.csv').write_text('Timestamp\n0\n',encoding='utf-8')
        loaded=[]
        def process(file_path, mesh, *args, **kwargs):
            loaded.append(mesh)
            return None, {}
        with patch.object(sample_mesh,'_CACHE_DIR_DEFAULT',self.cache), \
             patch.object(main,'cuda_device',return_value=torch.device('cuda')), \
             patch.object(main,'_process_record_file',side_effect=process), \
             patch.object(np.random,'default_rng',side_effect=AssertionError('Cache must not be resampled')), \
             contextlib.redirect_stdout(io.StringIO()):
            main.run_batch_job(records,self.mesh_path,sampling_density=3,
                               output_base=self.work/'results',**options)
        self.assertEqual(len(loaded),1)
        cached=pd.read_csv(self.csv)
        np.testing.assert_array_equal(loaded[0].sampled_points,cached[['ptc_X','ptc_Y','ptc_Z']].to_numpy())
        np.testing.assert_array_equal(loaded[0].face_indices,self.fresh.face_indices)

    def test_batch_explicit_cache_choice_needs_no_prompt_or_resampling(self):
        before=hashlib.sha256(self.csv.read_bytes()).hexdigest()
        for force in [True,False]:
            with self.subTest(force_usecache=force),patch('builtins.input',side_effect=AssertionError('Unexpected prompt')):
                self.run_batch_with_cache(force_usecache=force)
        self.assertEqual(hashlib.sha256(self.csv.read_bytes()).hexdigest(),before)

    def test_batch_default_preserves_interactive_cache_choice(self):
        with patch('builtins.input',return_value='') as prompt:
            self.run_batch_with_cache()
        prompt.assert_called_once()

    def setUp(self):
        output=Path(__file__).resolve().parents[2]/'test-env'/'package_validation'/'unit_tmp'
        output.mkdir(parents=True,exist_ok=True)
        temporary=tempfile.TemporaryDirectory(prefix='visibility_',dir=output)
        self.work=Path(temporary.name).resolve()
        self.assertTrue(self.work.is_relative_to(output.resolve()))
        self.addCleanup(temporary.cleanup)
        self.mesh_path=self.work/'box.obj'
        trimesh.creation.box(extents=[2,2,2]).export(self.mesh_path)
        self.cache=self.work/'cache'
        self.fresh=self.sample(force_recompute=True)
        self.csv=self.cache/'ptc_box_d3.csv'
        self.meta=self.cache/'ptc_box_d3_meta.csv'

    def sample(self,**kwargs):
        options=dict(mesh_path=self.mesh_path,sampling_density=3,cache_dir=self.cache,seed=42,force_usecache=False)
        options.update(kwargs)
        with contextlib.redirect_stdout(io.StringIO()):
            return sample_mesh.mesh_sampling(**options)

    def legacy(self):
        frame=pd.read_csv(self.csv).drop(columns='face_indices')
        frame.to_csv(self.csv,index=False)
        return frame

    def test_new_cache_round_trip_keeps_ids_and_points(self):
        loaded=self.sample()
        self.assertIn('face_indices',pd.read_csv(self.csv))
        self.assertEqual(pd.read_csv(self.meta).cache_version.iloc[0],2)
        np.testing.assert_array_equal(loaded.face_indices,self.fresh.face_indices)
        np.testing.assert_allclose(loaded.sampled_points,self.fresh.sampled_points,rtol=0,atol=1e-12)

    def test_legacy_cache_recovery_does_not_rewrite_or_resample(self):
        frame=self.legacy()
        before=hashlib.sha256(self.csv.read_bytes()).hexdigest()
        loaded=self.sample()
        self.assertEqual(hashlib.sha256(self.csv.read_bytes()).hexdigest(),before)
        np.testing.assert_array_equal(loaded.face_indices,self.fresh.face_indices)
        np.testing.assert_array_equal(loaded.sampled_points,frame[['ptc_X','ptc_Y','ptc_Z']].to_numpy())

    def test_legacy_points_off_inferred_triangles_keep_legacy_path(self):
        frame=self.legacy()
        frame['ptc_X']+=100
        frame.to_csv(self.csv,index=False)
        loaded=self.sample()
        self.assertIsNone(loaded.face_indices)
        np.testing.assert_allclose(loaded.sampled_points[:,0],frame.ptc_X,rtol=0,atol=1e-12)

    def test_legacy_reordered_rows_are_not_assigned_unverified_ids(self):
        frame=self.legacy().iloc[::-1]
        frame.to_csv(self.csv,index=False)
        self.assertIsNone(self.sample().face_indices)

    def test_legacy_wrong_point_count_keeps_existing_points(self):
        frame=self.legacy().iloc[:-1]
        frame.to_csv(self.csv,index=False)
        loaded=self.sample()
        self.assertIsNone(loaded.face_indices)
        self.assertEqual(len(loaded.sampled_points),len(frame))

    def test_corrupt_new_cache_ids_are_not_used(self):
        frame=pd.read_csv(self.csv)
        frame.loc[0,'face_indices']=-1
        frame.to_csv(self.csv,index=False)
        self.assertIsNone(self.sample().face_indices)

    def test_forced_cache_for_a_changed_source_does_not_use_ids(self):
        metadata=pd.read_csv(self.meta)
        metadata.loc[0,'src_mtime']-=10
        metadata.to_csv(self.meta,index=False)
        loaded=self.sample(force_usecache=True)
        self.assertIsNone(loaded.face_indices)
        np.testing.assert_allclose(loaded.sampled_points,self.fresh.sampled_points,rtol=0,atol=1e-12)


if __name__=='__main__': unittest.main()
