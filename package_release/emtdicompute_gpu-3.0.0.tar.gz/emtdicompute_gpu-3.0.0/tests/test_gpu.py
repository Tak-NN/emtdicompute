"""GPU backend regressions. Run with native binaries and caches in test-env."""
import contextlib
import io
import os
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import torch
import trimesh

from emtdicompute.gpu import GpuSession
from emtdicompute.gpu.engine import cuda_device
from emtdicompute.batch import pipeline
from emtdicompute.utils.datatypes import CameraPosDir, SampleMesh


def plane(x):
    return trimesh.Trimesh(vertices=[[x,-5,-5],[x,5,-5],[x,5,5],[x,-5,5]],
                          faces=[[0,1,2],[0,2,3]], process=False)


def sampled(geometry, points=None, faces=None):
    points=np.array([[10,1,-1]],dtype=float) if points is None else np.asarray(points,dtype=float)
    faces=np.zeros(len(points),dtype=np.int32) if faces is None else np.asarray(faces)
    return SampleMesh(points,np.ones(len(points),dtype=int),
                      np.tile([-1.,0.,0.],(len(points),1)),geometry,100,face_indices=faces)


class EnvironmentTests(unittest.TestCase):
    def test_cpu_device_is_explicitly_rejected(self):
        with self.assertRaisesRegex(ValueError,'CUDA device'):
            cuda_device('cpu')

    def test_missing_cuda_gives_actionable_error(self):
        with patch.object(torch.cuda,'is_available',return_value=False):
            with self.assertRaisesRegex(RuntimeError,'CUDA-enabled PyTorch'):
                cuda_device('cuda')


@unittest.skipUnless(torch.cuda.is_available(),'CUDA-enabled PyTorch and NVIDIA GPU required')
class GpuTests(unittest.TestCase):
    def test_native_assets_in_unicode_directory(self):
        output=Path(__file__).resolve().parents[2]/'test-env/package_validation/unit_tmp'
        output.mkdir(parents=True,exist_ok=True)
        source=Path(os.environ.get('EMTDI_GPU_LIBRARY_DIR',
            Path(__import__('emtdicompute.gpu.engine',fromlist=['__file__']).__file__).parent/'_native'))
        # Windows keeps ctypes DLLs loaded until process exit. Keep this test asset
        # under test-env rather than trying to remove a loaded DLL in-process.
        target=Path(tempfile.mkdtemp(prefix='native_日本語_',dir=output))
        for name in ['emtdi_optix.dll','libemtdi_optix.so','rays.ptx']:
            if (source/name).exists(): shutil.copy2(source/name,target/name)
        with patch.dict(os.environ,EMTDI_GPU_LIBRARY_DIR=str(target),EMTDI_GPU_CACHE_DIR=str(target/'cache')):
            with GpuSession(sampled(plane(10))) as session:
                mask=session.visibility(torch.tensor([0,1,-1],dtype=torch.float32,device='cuda'),
                    torch.tensor([[10,1,-1]],dtype=torch.float32,device='cuda'),
                    torch.tensor([0],dtype=torch.int32,device='cuda'))
                self.assertEqual(mask.tolist(),[True])

    def query(self, geometry, target, face, expected, origin=(0,1,-1)):
        data=sampled(geometry)
        with GpuSession(data) as session:
            result=session.visibility(torch.tensor(origin,dtype=torch.float32,device='cuda'),
                torch.tensor([target],dtype=torch.float32,device='cuda'),
                torch.tensor([face],dtype=torch.int32,device='cuda'))
            self.assertEqual(result.tolist(),[expected])

    def test_own_triangle_is_visible_even_if_hit_is_earlier(self):
        self.query(plane(10),[10.01,1,-1],0,True)

    def test_foreign_occluder_is_invisible(self):
        self.query(trimesh.util.concatenate([plane(3),plane(10)]),[10,1,-1],2,False)

    def test_foreign_hit_after_target_is_visible(self):
        self.query(plane(15),[10,1,-1],0,True)

    def test_foreign_hit_within_epsilon_is_visible(self):
        self.query(trimesh.util.concatenate([plane(10-5e-5),plane(10)]),[10,1,-1],2,True)

    def test_adjacent_triangle_is_not_a_face_group(self):
        self.query(plane(10),[10.01,1,-1],1,False)

    def test_no_hit_is_visible(self):
        self.query(plane(10),[-10,1,-1],0,True)

    def test_translated_scene(self):
        geometry=trimesh.util.concatenate([plane(3),plane(10)])
        geometry.apply_translation([10000,10000,10000])
        self.query(geometry,[10010,10001,9999],2,False,origin=(10000,10001,9999))

    def test_coincident_target(self):
        self.query(plane(10),[0,1,-1],0,True)

    def test_missing_and_invalid_source_ids(self):
        for faces in [None,np.array([-1]),np.array([2]),np.array([.5]),np.array([[0]])]:
            data=sampled(plane(10)); data.face_indices=faces
            with self.subTest(faces=faces),self.assertRaisesRegex(ValueError,'face_indices'):
                GpuSession(data)

    def test_nondefault_stream_and_parameter_slot_reuse(self):
        data=sampled(trimesh.util.concatenate([plane(3),plane(10)]),points=[[3,1,-1],[10,1,-1]],faces=[0,2])
        session=GpuSession(data)
        self.addCleanup(session.close)
        camera=CameraPosDir(np.array([[0,1,-1],[0,1,-1]],dtype=float),np.array([[1,0,0],[1,0,0]],dtype=float))
        stream=torch.cuda.Stream()
        with torch.cuda.stream(stream):
            for _ in range(70):
                result=session.prelims(camera,torch.tensor([[True,True],[False,False]],device='cuda'))
                self.assertEqual(result.frame_indices.tolist(),[0])
                self.assertEqual(result.visible_points_allframes.tolist(),[[3.,1.,-1.]])
            empty=session.prelims(camera,torch.zeros((2,2),dtype=torch.bool,device='cuda'))
            self.assertEqual(empty.total_frames,2)
            self.assertEqual(empty.visible_points_allframes.shape,(0,3))
        stream.synchronize()
        session.close(); session.close()
        with self.assertRaisesRegex(RuntimeError,'closed'):
            session.prelims(camera,torch.zeros((2,2),device='cuda'))

    def test_batch_builds_one_scene_and_preserves_metrics_selection(self):
        data=sampled(trimesh.util.concatenate([plane(3),plane(10)]),points=[[3,1,-1],[10,1,-1]],faces=[0,2])
        camera=CameraPosDir(np.array([[0,1,-1],[0,1,-1]],dtype=float),np.array([[1,0,0],[-1,0,0]],dtype=float))
        with patch.object(pipeline,'GpuSession',wraps=GpuSession) as create,contextlib.redirect_stdout(io.StringIO()):
            result=pipeline.compute_em3di_metrics_batch(data,camera,1,save_each_chunk=False,
                timestamps=np.array([1.,2.]),metrics=['visible_volume'])
        self.assertEqual(create.call_count,1)
        self.assertEqual(result.Timestamp.tolist(),[1.,2.])
        self.assertNotIn('vh_ratio',result)
        np.testing.assert_allclose(result.visible_volume,[.01,0],atol=1e-7,rtol=0)

    def test_session_rejects_different_mesh_and_bad_mask(self):
        data=sampled(plane(10))
        with GpuSession(data) as session:
            with self.assertRaisesRegex(ValueError,'different SampleMesh'):
                session.check(sampled(plane(10)),'cuda')
            camera=CameraPosDir(np.array([[0,1,-1]]),np.array([[1,0,0]]))
            with self.assertRaisesRegex(ValueError,'FOV mask'):
                session.prelims(camera,torch.zeros((1,2),device='cuda'))


if __name__=='__main__': unittest.main()
