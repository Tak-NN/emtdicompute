# emtdicompute-gpu 3.0.0

The GPU edition of Embodied 3D Isovist computation. Distribution name: `emtdicompute-gpu`. Python import: `emtdicompute`. Use a separate virtual environment from the CPU distribution because both provide the same Python namespace.

## Release files

- [Windows x64 wheel](../package_release/emtdicompute_gpu-3.0.0-py3-none-win_amd64.whl)
- [Source archive](../package_release/emtdicompute_gpu-3.0.0.tar.gz)

The CPU-intersection edition is distributed separately as `emtdicompute 2.0.0`.

## Runtime requirements

- Python 3.12 or newer; Python 3.12 is tested.
- NVIDIA GPU and a driver supporting OptiX 9.1 and the selected CUDA-enabled PyTorch build.
- CUDA-enabled PyTorch 2.9 or newer. Install the build appropriate to your driver before this package; CPU-only PyTorch cannot execute this edition.
- Windows native wheels also require the Microsoft Visual C++ runtime.

Validated environment: Windows x64, RTX 5070, NVIDIA driver 610.88, PyTorch 2.9.1+cu130. Building used CUDA Toolkit 12.8, OptiX 9.1 headers, and Visual Studio 2022 C++ tools. These are tested versions, not a claim that driver 610.88 is the minimum supported version. The source builder also includes a Linux x86_64 path; Linux builds and multi-GPU execution have not been verified on hardware in this workspace. macOS is unsupported.

## Install a built wheel

Install CUDA-enabled PyTorch first in a virtual environment dedicated to the GPU
edition. From the repository root, install or upgrade the platform wheel:

```powershell
python -m pip install --upgrade .\package_release\emtdicompute_gpu-3.0.0-py3-none-win_amd64.whl
python -c "import emtdicompute; print(emtdicompute.__version__); print(emtdicompute.__file__)"
```

A built wheel includes the native bridge and PTX. End users do not need the CUDA Toolkit, OptiX headers, or a C++ compiler. Importing the package does not initialize the GPU; CUDA and OptiX are checked when a session is created. The wheel is platform specific but does not link against the CPython or PyTorch C++ ABI.

For a downloaded wheel, use its actual path instead. The version check should
print `3.0.0`. Restart a running Python/notebook session after an upgrade.
To replace a file with the same installed version and keep existing dependencies:

```powershell
python -m pip install --force-reinstall --no-deps .\package_release\emtdicompute_gpu-3.0.0-py3-none-win_amd64.whl
```

## Build/install from source

In addition to the runtime requirements, install:

- CUDA Toolkit with `nvcc`, Driver API headers, and link libraries; set `CUDA_PATH` (Windows) or `CUDA_HOME` (Linux) if `nvcc` is not on PATH.
- OptiX **9.1** headers; set `OPTIX_ROOT` to the SDK directory containing `include/optix.h`. Headers and SDK licenses are supplied separately by NVIDIA; they are not downloaded automatically or bundled into this source package.
- Windows: Visual Studio 2022 C++ Build Tools, x64. The builder discovers them with `vswhere` or uses an x64 Native Tools prompt.
- Linux: a C++17 compiler and CUDA Driver API link library/stub. This path is implemented but untested here.

From `package_main/` in PowerShell:

```powershell
$env:OPTIX_ROOT = 'C:\path\to\OptiX-9.1'
python -m pip install .
```

Build an installable wheel without publishing it:

```powershell
python -m pip wheel . --no-deps --wheel-dir .\dist
```

For editable development, install then build the in-place native files explicitly:

```powershell
python -m pip install -e .
python -m emtdicompute.gpu.build --optix-include "$env:OPTIX_ROOT\include"
```

The native builder can write to an external directory instead:

```powershell
python -m emtdicompute.gpu.build --optix-include "$env:OPTIX_ROOT\include" --output-dir C:\work\emtdi-native
$env:EMTDI_GPU_LIBRARY_DIR = 'C:\work\emtdi-native'
$env:EMTDI_GPU_CACHE_DIR = 'C:\work\emtdi-cache'
```

`EMTDI_GPU_LIBRARY_DIR` must contain `emtdi_optix.dll` (Windows) or `libemtdi_optix.so` (Linux), plus `rays.ptx`. Normal wheels load from their package directory. OptiX caches go to the user cache by default, or below `EMTDI_GPU_CACHE_DIR` when set. The backend does not compile or download code at runtime. Build failures are reported with their compiler-log location.

## Compute metrics

The existing sampling, camera, and pipeline interfaces are retained. Source triangle IDs must be available; unverified old caches must be regenerated.

```python
import pandas as pd
from emtdicompute.scene.sample_mesh import mesh_sampling
from emtdicompute.camera_handler.camera import (
    extract_camera_from_record, combine_camera_pos_and_dir,
)
from emtdicompute.batch.pipeline import compute_em3di_metrics_batch

mesh = mesh_sampling('building.obj', sampling_density=100,
                     force_usecache=False, cache_dir='outputs/pointcloud')
record = pd.read_csv('trajectory.csv')
origins, forwards = extract_camera_from_record(record)
camera = combine_camera_pos_and_dir(origins, forwards)
metrics = compute_em3di_metrics_batch(
    mesh, camera, chunk_size=10, device='cuda',
    timestamps=record['Timestamp'].to_numpy(),
    temp_dir='outputs/chunks', save_each_chunk=True,
)
metrics.to_csv('outputs/metrics.csv', index=False)
```

`run_batch_job()` also accepts `force_usecache`:

```python
from emtdicompute.main import run_batch_job

run_batch_job(
    './Bldg4_14', './bldg_obj/bldg4_for_emtdi.obj',
    temp_dir='./outputs/em3di_metrics/temp_bldg4_14',
    sampling_density=200,
    force_usecache=True,
)
```

`True` forces reuse of an existing point-cloud cache even when source metadata differ; `False` uses normal metadata validation. Both avoid the interactive cache question. The default `None` preserves that question. If no cache exists, sampling proceeds normally. GPU visibility still requires verified source triangle IDs; forcing an unverified cache does not bypass that requirement.

One GPU session is automatically reused across chunks. If several trajectories share a building, explicitly reuse a session:

```python
from emtdicompute.gpu import GpuSession

with GpuSession(mesh, device='cuda:0') as session:
    metrics = compute_em3di_metrics_batch(
        mesh, camera, chunk_size=10, device='cuda:0',
        gpu_session=session, save_each_chunk=False,
    )
```

Do not mutate the mesh or sampled arrays while a session is open. Close it with a context manager to release the native scene. CUDA device selection is explicit and there is no CPU fallback. Initial loading and sampling still run on the CPU; small camera/launch parameters, selection-count synchronization, logging, and final CSV transfers remain.

## Numerical behavior

Visibility uses the closest hit and two-sided triangles. A sampled point's own source triangle is visible; adjacent triangles are not merged. Other hit distances use the existing `1e-4` tolerance. The validated GPU input preparation retains both normalizations and the scene transformation used during CPU/GPU comparisons.

The package retains the existing metric formulas and float32 PyTorch scatter accumulations. Their results can vary with addition order between runs. Matching visible points does not guarantee bit-identical CSV metrics, nor a fixed 0.001 m³ bound for VisibleVolume. The CPU and OptiX intersection engines can also disagree on a small number of triangle-edge cases.
