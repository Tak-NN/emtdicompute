"""Regression checks; all temporary files are kept under repository/test-env."""
import contextlib
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import pandas as pd
import torch
import trimesh
from trimesh.ray.ray_pyembree import RayMeshIntersector

from emtdicompute.embodied_3d_isovist import isovist
from emtdicompute.scene import sample_mesh
from emtdicompute.utils.datatypes import CameraPosDir, SampleMesh


def plane(x):
    return trimesh.Trimesh(vertices=[[x,-5,-5],[x,5,-5],[x,5,5],[x,-5,5]],
        faces=[[0,1,2],[0,2,3]],process=False)


class VisibilityTests(unittest.TestCase):
    def check_ray(self,mesh,target,face,expected,origin=None,direction=None):
        origin=np.array([0,1,-1],dtype=np.float32) if origin is None else origin
        direction=np.array([[1,0,0]],dtype=np.float32) if direction is None else direction
        actual=isovist._first_hit_visibility(RayMeshIntersector(mesh),origin,direction,
            np.array([target],dtype=np.float32),np.array([face],dtype=np.int32))
        self.assertEqual(actual.shape,(1,))
        self.assertEqual(bool(actual[0]),expected)

    def test_own_triangle_is_visible_even_if_hit_is_earlier(self):
        self.check_ray(plane(10),[10.01,1,-1],0,True)

    def test_foreign_occluder_is_invisible(self):
        mesh=trimesh.util.concatenate([plane(3),plane(10)])
        self.check_ray(mesh,[10,1,-1],2,False)

    def test_foreign_hit_after_target_is_visible(self):
        self.check_ray(plane(15),[10,1,-1],0,True)

    def test_foreign_hit_within_epsilon_is_visible(self):
        mesh=trimesh.util.concatenate([plane(10-5e-5),plane(10)])
        self.check_ray(mesh,[10,1,-1],2,True)

    def test_adjacent_coplanar_triangle_is_not_a_face_group(self):
        self.check_ray(plane(10),[10.01,1,-1],1,False)

    def test_no_hit_is_visible(self):
        self.check_ray(plane(10),[-10,1,-1],0,direction=np.array([[-1,0,0]],dtype=np.float32),expected=True)

    def test_scene_translation_and_scale(self):
        geometry=trimesh.util.concatenate([plane(3),plane(10)])
        geometry.apply_translation([10000,10000,10000])
        self.check_ray(geometry,[10010,10001,9999],2,False,
            origin=np.array([10000,10001,9999],dtype=np.float32))

    def test_prelims_preserves_frame_indices_and_empty_frames(self):
        mesh=trimesh.util.concatenate([plane(3),plane(10)])
        points=np.array([[3,1,-1],[10,1,-1]],dtype=float)
        sampled=SampleMesh(points,np.array([1,1]),np.array([[-1,0,0],[-1,0,0]]),mesh,100,
            face_indices=np.array([0,2],dtype=np.int32))
        camera=CameraPosDir(np.array([[0,1,-1],[0,1,-1]],dtype=float),np.array([[1,0,0],[1,0,0]],dtype=float))
        with contextlib.redirect_stdout(io.StringIO()):
            result=isovist.embodied_3d_isovist_prelims(sampled,camera,
                torch.tensor([[True,True],[False,False]]),device='cpu')
        self.assertEqual(result.total_frames,2)
        self.assertEqual(result.frame_indices.tolist(),[0])
        np.testing.assert_array_equal(result.visible_points_allframes.numpy(),points[:1])

    def test_five_argument_samplemesh_keeps_legacy_path(self):
        points=np.array([[10,1,-1]],dtype=float)
        sampled=SampleMesh(points,np.array([1]),np.array([[-1,0,0]]),plane(10),100)
        self.assertIsNone(sampled.face_indices)
        camera=CameraPosDir(np.array([[0,1,-1]],dtype=float),np.array([[1,0,0]],dtype=float))
        with patch.object(isovist,'_first_hit_visibility',side_effect=AssertionError('Unexpected fast path')):
            with contextlib.redirect_stdout(io.StringIO()):
                result=isovist.embodied_3d_isovist_prelims(sampled,camera,torch.ones((1,1),dtype=torch.bool),device='cpu')
        self.assertEqual(len(result.visible_points_allframes),1)

    def test_invalid_explicit_face_ids_fail_before_query(self):
        camera=CameraPosDir(np.array([[0,1,-1]],dtype=float),np.array([[1,0,0]],dtype=float))
        for ids in [np.array([-1]),np.array([2]),np.array([.5]),np.array([[0]]),np.array([],dtype=int)]:
            sampled=SampleMesh(np.array([[10,1,-1]],dtype=float),np.array([1]),
                np.array([[-1,0,0]]),plane(10),100,face_indices=ids)
            with self.subTest(ids=ids),contextlib.redirect_stdout(io.StringIO()):
                with self.assertRaisesRegex(ValueError,'face_indices'):
                    isovist.embodied_3d_isovist_prelims(sampled,camera,torch.ones((1,1),dtype=torch.bool),device='cpu')


class CacheTests(unittest.TestCase):
    def setUp(self):
        output=Path(__file__).resolve().parents[2]/'test-env'/'package_validation'/'unit_tmp'
        output.mkdir(parents=True,exist_ok=True)
        temporary=tempfile.TemporaryDirectory(prefix='visibility_',dir=output)
        self.work=Path(temporary.name).resolve()
        self.assertTrue(self.work.is_relative_to(output.resolve()))
        self.addCleanup(temporary.cleanup)
        self.mesh_path=self.work/'box.obj'
        trimesh.creation.box(extents=[2,2,2]).export(self.mesh_path)
        self.cache=self.work/'cache'
        self.fresh=self.sample(force_recompute=True)
        self.csv=self.cache/'ptc_box_d3.csv'
        self.meta=self.cache/'ptc_box_d3_meta.csv'

    def sample(self,**kwargs):
        options=dict(mesh_path=self.mesh_path,sampling_density=3,cache_dir=self.cache,seed=42,force_usecache=False)
        options.update(kwargs)
        with contextlib.redirect_stdout(io.StringIO()):
            return sample_mesh.mesh_sampling(**options)

    def legacy(self):
        frame=pd.read_csv(self.csv).drop(columns='face_indices')
        frame.to_csv(self.csv,index=False)
        return frame

    def test_new_cache_round_trip_keeps_ids_and_points(self):
        loaded=self.sample()
        self.assertIn('face_indices',pd.read_csv(self.csv))
        self.assertEqual(pd.read_csv(self.meta).cache_version.iloc[0],2)
        np.testing.assert_array_equal(loaded.face_indices,self.fresh.face_indices)
        np.testing.assert_allclose(loaded.sampled_points,self.fresh.sampled_points,rtol=0,atol=1e-12)

    def test_legacy_cache_recovery_does_not_rewrite_or_resample(self):
        frame=self.legacy()
        before=hashlib.sha256(self.csv.read_bytes()).hexdigest()
        loaded=self.sample()
        self.assertEqual(hashlib.sha256(self.csv.read_bytes()).hexdigest(),before)
        np.testing.assert_array_equal(loaded.face_indices,self.fresh.face_indices)
        np.testing.assert_array_equal(loaded.sampled_points,frame[['ptc_X','ptc_Y','ptc_Z']].to_numpy())

    def test_legacy_points_off_inferred_triangles_keep_legacy_path(self):
        frame=self.legacy()
        frame['ptc_X']+=100
        frame.to_csv(self.csv,index=False)
        loaded=self.sample()
        self.assertIsNone(loaded.face_indices)
        np.testing.assert_allclose(loaded.sampled_points[:,0],frame.ptc_X,rtol=0,atol=1e-12)

    def test_legacy_reordered_rows_are_not_assigned_unverified_ids(self):
        frame=self.legacy().iloc[::-1]
        frame.to_csv(self.csv,index=False)
        self.assertIsNone(self.sample().face_indices)

    def test_legacy_wrong_point_count_keeps_existing_points(self):
        frame=self.legacy().iloc[:-1]
        frame.to_csv(self.csv,index=False)
        loaded=self.sample()
        self.assertIsNone(loaded.face_indices)
        self.assertEqual(len(loaded.sampled_points),len(frame))

    def test_corrupt_new_cache_ids_are_not_used(self):
        frame=pd.read_csv(self.csv)
        frame.loc[0,'face_indices']=-1
        frame.to_csv(self.csv,index=False)
        self.assertIsNone(self.sample().face_indices)

    def test_forced_cache_for_a_changed_source_does_not_use_ids(self):
        metadata=pd.read_csv(self.meta)
        metadata.loc[0,'src_mtime']-=10
        metadata.to_csv(self.meta,index=False)
        loaded=self.sample(force_usecache=True)
        self.assertIsNone(loaded.face_indices)
        np.testing.assert_allclose(loaded.sampled_points,self.fresh.sampled_points,rtol=0,atol=1e-12)


if __name__=='__main__': unittest.main()
