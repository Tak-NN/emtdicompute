"""Device-independent visible-point selection and CPU-only execution."""
import contextlib
import io
import unittest
from unittest.mock import patch

import numpy as np
import torch
import trimesh

from emtdicompute.batch import pipeline
from emtdicompute.embodied_3d_isovist import isovist
from emtdicompute.utils.datatypes import CameraPosDir, SampleMesh
from emtdicompute.utils.device import resolve_device


def inputs():
    geometry=trimesh.Trimesh(vertices=[[3,-5,-5],[3,5,-5],[3,5,5],[3,-5,5],
                                     [10,-5,-5],[10,5,-5],[10,5,5],[10,-5,5]],
                             faces=[[0,1,2],[0,2,3],[4,5,6],[4,6,7]],process=False)
    mesh=SampleMesh(np.array([[3,1,-1],[10,1,-1],[3,2,-1]],dtype=np.float64),np.array([0,1,1]),
                    np.array([[-1,0,0],[-1,0,0],[-1,0,0]],dtype=np.float64),geometry,100,
                    face_indices=np.array([0,2,0]))
    camera=CameraPosDir(np.array([[0,1,-1],[0,1,-1]],dtype=float),np.array([[1,0,0],[-1,0,0]],dtype=float))
    return mesh,camera


class TransferTests(unittest.TestCase):
    def check_fields(self,device):
        mesh,camera=inputs()
        mask=torch.tensor([[True,True,True],[False,False,False]],device=device)
        with contextlib.redirect_stdout(io.StringIO()):
            result=isovist.embodied_3d_isovist_prelims(mesh,camera,mask,device=device,num_workers=4)
        expected=np.array([0,2])
        for field,source,dtype in [('visible_points_allframes',mesh.sampled_points,torch.float32),
                                  ('normals_visipts_allframes',mesh.face_normals,torch.float32),
                                  ('vhlbls_visipts_allframes',mesh.face_vh_labels,torch.int32)]:
            actual=getattr(result,field)
            self.assertEqual(actual.device.type,device)
            self.assertTrue(torch.equal(actual,torch.as_tensor(source[expected],dtype=dtype,device=device)))
        self.assertEqual(result.total_frames,2)
        self.assertEqual(result.frame_indices.tolist(),[0,0])

    def test_cpu_visible_fields_and_empty_frames(self):
        self.check_fields('cpu')

    @unittest.skipUnless(torch.cuda.is_available(),'CUDA is optional')
    def test_cuda_visible_fields_and_empty_frames(self):
        self.check_fields('cuda')

    def test_cpu_pipeline_never_initializes_or_synchronizes_cuda(self):
        mesh,camera=inputs()
        with patch.object(torch.cuda,'is_available',return_value=False), \
             patch.object(torch.cuda,'_lazy_init',side_effect=AssertionError('CUDA must not initialize')), \
             patch.object(torch.cuda,'synchronize',side_effect=AssertionError('CUDA must not synchronize')), \
             contextlib.redirect_stdout(io.StringIO()):
            auto=pipeline.compute_em3di_metrics_batch(mesh,camera,1,save_each_chunk=False,num_workers=4)
            explicit=pipeline.compute_em3di_metrics_batch(mesh,camera,1,device='cpu',save_each_chunk=False,num_workers=1)
        np.testing.assert_array_equal(auto.to_numpy(),explicit.to_numpy())
        self.assertTrue(np.isfinite(auto[['vh_ratio','td_ratio','v_jaggedness','visible_volume']].to_numpy()).all())

    def test_explicit_cpu_does_not_probe_cuda(self):
        with patch.object(torch.cuda,'is_available',side_effect=AssertionError('CPU must not need a GPU probe')):
            self.assertEqual(resolve_device('cpu'),torch.device('cpu'))

    def test_explicit_unavailable_cuda_has_clear_error(self):
        with patch.object(torch.cuda,'is_available',return_value=False):
            with self.assertRaisesRegex(RuntimeError,"device='cpu'"):
                resolve_device('cuda')
