"""CPU-only checks for concurrent Embree queries and the public batch API."""
import contextlib
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import pandas as pd
import trimesh
from trimesh.ray.ray_pyembree import RayMeshIntersector

from emtdicompute import main
from emtdicompute.batch import pipeline
from emtdicompute.embodied_3d_isovist import isovist
from emtdicompute.embodied_3d_isovist._parallel import EmbreeQueries
from emtdicompute.utils.datatypes import SampleMesh


def plane(x):
    return trimesh.Trimesh(vertices=[[x,-5,-5],[x,5,-5],[x,5,5],[x,-5,5]],
                          faces=[[0,1,2],[0,2,3]],process=False)


class ParallelTests(unittest.TestCase):
    def test_parallel_first_hits_and_visibility_match_serial_on_fresh_scene(self):
        geometry=trimesh.util.concatenate([plane(3),plane(10)])
        count=131073
        rng=np.random.default_rng(1442)
        targets=rng.uniform(-20,20,(count,3)).astype(np.float32)
        targets[:,0]=10
        origin=np.array([0,1,-1],dtype=np.float32)
        directions=targets-origin
        directions/=np.linalg.norm(directions,axis=1,keepdims=True)
        faces=np.full(count,2,dtype=np.int32)
        serial=RayMeshIntersector(geometry)
        expected=isovist._first_hit_visibility(serial,origin,directions,targets,faces)
        scene=serial._scene
        native_dirs=np.ascontiguousarray(trimesh.util.unitize(directions.astype(np.float64)),dtype=np.float32)
        native_origins=np.repeat(((origin.astype(np.float64)-scene.origin)*scene.scale).astype(np.float32)[None,:],count,axis=0)
        reference=scene.scene.run(native_origins,native_dirs,query='INTERSECT',output=True)
        for workers in [2,4,16]:
            with self.subTest(num_workers=workers):
                intersector=RayMeshIntersector(geometry)
                manager=EmbreeQueries(workers)
                with manager as run,patch.object(manager.pool,'map',wraps=manager.pool.map) as dispatch:
                    actual=isovist._first_hit_visibility(intersector,origin,directions,targets,faces,query_runner=run)
                    dispatch.assert_called_once()
                    hits=run(intersector._scene,native_origins,native_dirs)
                np.testing.assert_array_equal(actual,expected)
                np.testing.assert_array_equal(hits['primID'],reference['primID'])
                np.testing.assert_array_equal(hits['tfar'],reference['tfar'])
        self.assertTrue(expected.any())
        self.assertTrue((~expected).any())

    def test_small_ray_groups_do_not_dispatch_to_workers(self):
        scene=RayMeshIntersector(plane(10))._scene
        origin=((np.array([0,1,-1])-scene.origin)*scene.scale).astype(np.float32)[None,:]
        with EmbreeQueries(8) as run:
            hits=run(scene,origin,np.array([[1,0,0]],dtype=np.float32))
        self.assertEqual(hits['primID'].tolist(),[0])

    def test_invalid_worker_counts_fail_before_inputs_or_files_are_used(self):
        for workers in [0,-1,1.5,'4',None,True]:
            for name,call in [
                ('main',lambda:main.run_batch_job(num_workers=workers)),
                ('batch',lambda:pipeline.compute_em3di_metrics_batch(None,None,10,num_workers=workers)),
                ('single',lambda:pipeline.compute_em3di_metrics(None,None,num_workers=workers)),
                ('prelims',lambda:isovist.embodied_3d_isovist_prelims(None,None,None,num_workers=workers)),
            ]:
                with self.subTest(num_workers=workers,api=name),contextlib.redirect_stdout(io.StringIO()):
                    with self.assertRaisesRegex(ValueError,'num_workers'):
                        call()

    def test_run_batch_job_cpu_results_match_across_worker_counts(self):
        output=Path(__file__).resolve().parents[2]/'test-env/cpu_workers/unit_tmp'
        output.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(dir=output) as temporary:
            root=Path(temporary)
            records=root/'records'; records.mkdir()
            df=pd.DataFrame(dict(PlayerID=['p','p'],Scene=['s','s'],Task=['t','t'],Timestamp=[0.,1.],
                Position_X=[0.,-1.],Position_Y=[1.,1.],Position_Z=[-1.,-1.],
                HeadDir_X=[1.,1.],HeadDir_Y=[0.,0.],HeadDir_Z=[0.,0.]))
            df.to_csv(records/'record.csv',index=False)
            count=131073
            points=np.tile([3.,1.,-1.],(count,1)); points[1::2,0]=10
            faces=np.zeros(count,dtype=np.int32); faces[1::2]=2
            mesh=SampleMesh(points,np.ones(count,dtype=int),np.tile([-1.,0.,0.],(count,1)),
                trimesh.util.concatenate([plane(3),plane(10)]),100,face_indices=faces)
            results=[]
            for workers in [1,4]:
                run=root/f'workers_{workers}'
                with patch.object(main.torch.cuda,'is_available',return_value=True), \
                     patch.object(main.torch.cuda,'_lazy_init',side_effect=AssertionError('Explicit CPU must not initialize CUDA')), \
                     patch.object(main.sample_mesh,'mesh_sampling',return_value=mesh), \
                     contextlib.redirect_stdout(io.StringIO()):
                    main.run_batch_job(records,root/'building.obj',chunk_size=2,
                        output_base=run/'results',temp_dir=run/'chunks',num_workers=workers,device='cpu')
                results.append(pd.read_csv(run/'results/em3dimets_record.csv'))
            pd.testing.assert_frame_equal(results[0],results[1],check_exact=True)
            self.assertTrue((results[0].visible_volume>0).all())


if __name__=='__main__': unittest.main()
